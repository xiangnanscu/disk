# c9.ide.language.python

Python code completion and linting for the Cloud9 IDE

Please refer to the SDK documentation at
https://cloud9-sdk.readme.io/v0.1/docs/language-tooling and
https://cloud9-sdk.readme.io/v0.1/docs/existing-tools
for an overview of the APIs and techniques used in this plugin.

# Using This Plugin

This plugin is available by default. You can set whether your project is using Python2 or Python3 by going to
Cloud9 > Preferences > Project Settings > Python Support > Python Version.

## License

MIT
